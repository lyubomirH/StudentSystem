﻿using StudentSystem.Date.Entites;

namespace StudentSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var context = new StudentSystemContext();
        }
    }
}
