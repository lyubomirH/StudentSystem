﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSystem.Date.Entites.Enum
{
    public enum ResourcesEnum
    {
        Video,
        Presentation,
        Document,
        Other

    }
}
